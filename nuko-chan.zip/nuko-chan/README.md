# Nuko-Chan Discord Bot 🐾

A cute Discord bot with toggleable NSFW/SFW modes and anime image generation.

## Setup

1. Copy `.env.example` to `.env` and add your tokens.
2. Run `pip install -r requirements.txt`
3. Start the bot: `python bot.py`
